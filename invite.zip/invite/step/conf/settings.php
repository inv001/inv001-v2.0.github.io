<?php

$settings = array(
	"chat_id"		=> "1948706802",	// Chat ID Of You
	"bot_url"		=> "bot7719938730:AAFe1G5D1q-I7tyDbSPnNrbFf6T4SvSPPVo",	// Your Bot API Key (ADD "bot" BEFORE API KEY)
);
return $settings;

?>